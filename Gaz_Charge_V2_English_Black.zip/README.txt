GAS CHARGE — V2 English / Black Theme

Based directly on the uploaded V2 HTML file.
The calculation data and formulas are unchanged.
Open index.html in a browser.
